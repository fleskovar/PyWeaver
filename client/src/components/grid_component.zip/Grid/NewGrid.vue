<template>
    <table>
    <thead>
      <tr>
        <th>-</th>
        <th v-for="(key, index) in columns" @click="sortBy(key)" :class="{ active: sortKey == key}" :key='index' @paste="(val) =>{parseVal(val, i, j)}">
          {{ key | capitalize }}
          <span class="arrow" :class="sortOrders[key] > 0 ? 'asc' : 'dsc'">
          </span>
        </th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(row, i) in filteredData" :key='"row_"+i'> 
          <td>{{i}}</td>       
          <Cell v-for="(col_name, j) in columns" :key='"cell_"+i+"_"+j' v-model='row[j]' :row="row" :k="j" @paste="(val) =>{parseVal(val, i, j)}"></Cell>
      </tr>
    </tbody>
  </table>
</template>

<style scoped>
    table {
    border: 2px solid #42b983;
    border-radius: 3px;
    background-color: #fff;
    }

    th {
    background-color: #42b983;
    color: rgba(255, 255, 255, 0.66);
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    }

    td {
    background-color: #f9f9f9;
    }

    th,
    td {
    min-width: 50px;
    padding: 5px 20px;
    }

    th.active {
    color: #fff;
    }

    th.active .arrow {
    opacity: 1;
    }

    .arrow {
    display: inline-block;
    vertical-align: middle;
    width: 0;
    height: 0;
    margin-left: 5px;
    opacity: 0.66;
    }

    .arrow.asc {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-bottom: 4px solid #fff;
    }

    .arrow.dsc {
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #fff;
    }
</style>

<script>
import Cell from './Cell'

export default {
    props: ['value', 'columns', 'filterKey'],
  components:{
    Cell
  },
  data: function() {
    var sortOrders = {}
    this.columns.forEach(function(key) {
      sortOrders[key] = 1
    })
    return {
      sortKey: '',
      sortOrders: sortOrders
    }
  },
  computed: {
    filteredData: function() {
      var sortKey = this.sortKey
      var filterKey = this.filterKey && this.filterKey.toLowerCase()
      var order = this.sortOrders[sortKey] || 1
      var value = this.value
      if (filterKey) {
        value = value.filter(function(row) {
          return Object.keys(row).some(function(key) {
            return String(row[key]).toLowerCase().indexOf(filterKey) > -1
          })
        })
      }
      if (sortKey) {
        value = value.slice().sort(function(a, b) {
          a = a[sortKey]
          b = b[sortKey]
          return (a === b ? 0 : a > b ? 1 : -1) * order
        })
      }
      return value
    }
  },
  filters: {
    capitalize: function(str) {
      return str.charAt(0).toUpperCase() + str.slice(1)
    }
  },
  methods: {
    sortBy: function(key) {
      this.sortKey = key
      this.sortOrders[key] = this.sortOrders[key] * -1
    },
    parseVal: function(val, i, j){
      console.log(val+"_"+i+"_"+j);
      this.parseText(val, i, j);
    },
    parseText(val, row, col){

        var current_rows = this.value.length;
        
        var max_cols = this.columns;

        var lines = val.split(/\r?\n/); //Regex split of new lines
        var new_lines = lines.length;
        
        for(var i = 0; i < new_lines; i++){
            
            var row_index = i + row;
            
            if(row_index > current_rows-1){
                //Checks if we need to an extra row
                this.value.push([]); //Append empty row at the bottom
                current_rows += 1;
            }

            let line = lines[i];
            var col_values = line.split('\t'); //Split tabs
            var new_cols = col_values.length;
        
            var current_cols= this.value[row_index].length;

            for(var j = 0; j < new_cols; j++){                        
                var col_index = col + j;

                if(col_index <= current_cols-1)
                    this.value[row_index][col_index] = col_values[j];       
                else{
                    this.value[row_index].push(col_values[j]);
                    current_cols += 1;
                }
            }
            
            if(current_cols > max_cols)
                max_cols = current_cols;
        }

        //Keep an empty row at the bottom 
        var final_length = this.value.length;
        if(this.value[final_length-1].length > 0)
            this.value.push([]);
        
        this.columns = max_cols;
        //this.updateRedrawKey();               
    },
  }
}
</script>

